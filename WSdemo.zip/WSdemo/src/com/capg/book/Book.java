package com.capg.book;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

@Path("/book")  //define url
public class Book {
	
	@GET 
	@Produces(MediaType.TEXT_XML)
	public String  sayHiXML(){
		
		String response="<?xml version='1.0' ?>"+
                "<hello> heloow XML</hello0>";
		
		
		return response;
	}
	/*@GET
	@Produces(MediaType.APPLICATION_JSON)
	public String  sayHiJson(){
		
		
		String response=null;
		return response;
	}
*/
}
